from django.contrib import admin
from django.urls import path
from django.shortcuts import redirect
from documents import views

urlpatterns = [

    # Redirect root "/" → "/login/"
    path("", lambda request: redirect("login"), name="home"),

    # Admin
    path("admin/", admin.site.urls),

    # Authentication
    path("login/", views.custom_login, name="login"),
    path("logout/", views.custom_logout, name="logout"),

    # Dashboard
    path("dashboard/", views.dashboard, name="dashboard"),

    # Document workflow
    path("documents/create/", views.create_document, name="create_document"),
    path("documents/<int:document_id>/", views.document_detail, name="document_detail"),
]